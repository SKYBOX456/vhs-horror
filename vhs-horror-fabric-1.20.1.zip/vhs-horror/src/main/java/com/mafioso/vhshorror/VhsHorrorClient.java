package com.mafioso.vhshorror;

import com.mafioso.vhshorror.entity.HerobrineRenderer;
import com.mafioso.vhshorror.entity.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourceType;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class VhsHorrorClient implements ClientModInitializer {
    public static final String MOD_ID = "vhs_horror";
    public static boolean enabled = true;

    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vhs_horror.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "category.vhs_horror"));

        EntityRendererRegistry.register(ModEntities.HEROBRINE, HerobrineRenderer::new);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) toggle(client);
            VhsEffect.tick(client);
        });

        WorldRenderEvents.END.register(ctx -> VhsEffect.render(ctx.tickDelta()));
        HudRenderCallback.EVENT.register(VhsHud::render);

        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(
                new SimpleSynchronousResourceReloadListener() {
                    @Override
                    public Identifier getFabricId() {
                        return new Identifier(MOD_ID, "reload");
                    }

                    @Override
                    public void reload(ResourceManager manager) {
                        VhsEffect.reset();
                    }
                });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("vhs").executes(c -> {
                    toggle(c.getSource().getClient());
                    return 1;
                })));
    }

    private static void toggle(MinecraftClient client) {
        enabled = !enabled;
        if (client.player != null) {
            client.player.sendMessage(Text.literal("VHS: " + (enabled ? "ON" : "OFF")), true);
        }
    }
}
