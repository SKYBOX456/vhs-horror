package com.mafioso.vhshorror.entity;

import com.mafioso.vhshorror.VhsHorrorClient;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {
    public static final EntityType<HerobrineEntity> HEROBRINE = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(VhsHorrorClient.MOD_ID, "herobrine"),
            FabricEntityTypeBuilder.create(SpawnGroup.MISC, HerobrineEntity::new)
                    .dimensions(EntityDimensions.fixed(0.6f, 1.8f))
                    .trackRangeBlocks(128)
                    .build());

    public static void register() {
        FabricDefaultAttributeRegistry.register(HEROBRINE, HerobrineEntity.createAttributes());
    }
}
