package com.mafioso.vhshorror.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Herobrine: fica parado te encarando de longe. Some se voce olha pra ele, chega perto ou bate nele. */
public class HerobrineEntity extends PathAwareEntity {
    private int stareTicks = 0;

    public HerobrineEntity(EntityType<? extends HerobrineEntity> type, World world) {
        super(type, world);
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 20.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.0);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.getWorld().isClient) return;

        PlayerEntity player = this.getWorld().getClosestPlayer(this, 128.0);
        if (player == null || player.isSpectator() || this.age > 20 * 45) {
            vanish();
            return;
        }

        this.lookAtEntity(player, 360.0f, 360.0f);
        this.setBodyYaw(this.getHeadYaw());
        this.setYaw(this.getHeadYaw());

        double dist = this.distanceTo(player);
        if (dist < 8.0) {
            vanish();
            return;
        }

        if (isPlayerLooking(player, dist)) {
            if (++stareTicks > 40) vanish(); // ~2 segundos encarando
        } else {
            stareTicks = Math.max(0, stareTicks - 1);
        }
    }

    private boolean isPlayerLooking(PlayerEntity player, double dist) {
        Vec3d look = player.getRotationVec(1.0f).normalize();
        Vec3d to = new Vec3d(this.getX() - player.getX(),
                this.getEyeY() - player.getEyeY(),
                this.getZ() - player.getZ());
        double len = to.length();
        to = to.normalize();
        return look.dotProduct(to) > 1.0 - 0.08 / len && player.canSee(this);
    }

    public void vanish() {
        if (this.getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1.0, getZ(), 20, 0.3, 0.6, 0.3, 0.02);
        }
        this.discard();
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (!this.getWorld().isClient) vanish();
        return false;
    }

    @Override public boolean isPushable() { return false; }
    @Override public boolean isFireImmune() { return true; }
    @Override public boolean canHaveStatusEffect(StatusEffectInstance effect) { return false; }
    @Override public boolean canImmediatelyDespawn(double distanceSquared) { return false; }
}
