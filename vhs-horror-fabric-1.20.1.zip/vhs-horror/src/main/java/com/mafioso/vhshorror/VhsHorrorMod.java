package com.mafioso.vhshorror;

import com.mafioso.vhshorror.entity.HerobrineEntity;
import com.mafioso.vhshorror.entity.ModEntities;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.Random;

public class VhsHorrorMod implements ModInitializer {
    private static final Random RNG = new Random();

    @Override
    public void onInitialize() {
        ModEntities.register();

        // A cada 10 segundos, 1 chance em 8 por jogador (media: ~80s entre aparicoes)
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            if (world.getRegistryKey() != World.OVERWORLD || world.getTime() % 200 != 0) return;
            for (ServerPlayerEntity player : world.getPlayers()) {
                if (player.isSpectator()) continue;
                if (RNG.nextInt(8) != 0) continue;
                if (!world.getEntitiesByClass(HerobrineEntity.class,
                        player.getBoundingBox().expand(160), e -> true).isEmpty()) continue;
                trySpawn(world, player);
            }
        });

        // /herobrine (precisa de permissao 2) = faz ele aparecer agora, para testar
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("herobrine")
                        .requires(src -> src.hasPermissionLevel(2))
                        .executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                            boolean ok = false;
                            for (int i = 0; i < 10 && !ok; i++) ok = trySpawn(p.getServerWorld(), p);
                            boolean result = ok;
                            ctx.getSource().sendFeedback(() -> Text.literal(
                                    result ? "..." : "Nao achei um lugar bom, tente de novo."), false);
                            return result ? 1 : 0;
                        })));
    }

    private static boolean trySpawn(ServerWorld world, PlayerEntity player) {
        double ang = RNG.nextDouble() * Math.PI * 2;
        double dist = 24 + RNG.nextDouble() * 14;
        int x = (int) Math.floor(player.getX() + Math.cos(ang) * dist);
        int z = (int) Math.floor(player.getZ() + Math.sin(ang) * dist);

        if (!world.isChunkLoaded(x >> 4, z >> 4)) return false;
        int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        BlockPos pos = new BlockPos(x, y, z);

        if (!world.getBlockState(pos.down()).isSideSolidFullSquare(world, pos.down(), Direction.UP)) return false;
        if (!world.getFluidState(pos).isEmpty()) return false;

        HerobrineEntity h = ModEntities.HEROBRINE.create(world);
        if (h == null) return false;
        h.refreshPositionAndAngles(x + 0.5, y, z + 0.5, 0, 0);
        world.spawnEntity(h);
        return true;
    }
}
