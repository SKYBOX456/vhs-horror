package com.mafioso.vhshorror;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class VhsHud {
    public static void render(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!VhsHorrorClient.enabled || mc.world == null || mc.options.hudHidden) return;

        TextRenderer tr = mc.textRenderer;
        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();

        ctx.drawText(tr, "PLAY \u25B6", 10, 10, 0xFFFFFFFF, true);

        if ((System.currentTimeMillis() / 600) % 2 == 0) {
            ctx.drawText(tr, "\u25CF REC", w - 50, 10, 0xFFFF3030, true);
        }

        LocalDateTime now = LocalDateTime.now().withYear(1998);
        String time = now.format(DateTimeFormatter.ofPattern("HH:mm:ss"));
        String date = now.format(DateTimeFormatter.ofPattern("MMM dd yyyy", Locale.ENGLISH)).toUpperCase(Locale.ROOT);
        ctx.drawText(tr, time, 10, h - 30, 0xFFFFFFFF, true);
        ctx.drawText(tr, date, 10, h - 20, 0xFFFFFFFF, true);
    }
}
