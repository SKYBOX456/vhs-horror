package com.mafioso.vhshorror;

import com.mafioso.vhshorror.entity.HerobrineEntity;
import com.mafioso.vhshorror.mixin.PostEffectProcessorAccessor;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.GlUniform;
import net.minecraft.client.gl.PostEffectPass;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.util.Random;

public class VhsEffect {
    private static final Identifier SHADER = new Identifier(VhsHorrorClient.MOD_ID, "shaders/post/vhs.json");
    private static final Random RNG = new Random();

    private static PostEffectProcessor chain;
    private static int lastW = -1, lastH = -1;

    private static final float BASE = 0.7f;
    private static float spike = 0f;
    private static int cooldown = 600;
    private static boolean heroPresent = false;

    public static void reset() {
        if (chain != null) {
            chain.close();
            chain = null;
        }
        lastW = lastH = -1;
    }

    /** Roda 20x por segundo: controla os "sustos" (picos de glitch + som). */
    public static void tick(MinecraftClient mc) {
        if (!VhsHorrorClient.enabled || mc.world == null || mc.isPaused()) return;

        spike = Math.max(0f, spike - 0.04f);

        // Herobrine por perto: o glitch aumenta quanto mais perto ele esta.
        // Quando ele some, vem o susto.
        if (mc.player != null) {
            java.util.List<HerobrineEntity> list = mc.world.getEntitiesByClass(
                    HerobrineEntity.class, mc.player.getBoundingBox().expand(128), e -> true);
            boolean present = !list.isEmpty();
            if (present) {
                double nearest = 128;
                for (HerobrineEntity h : list) nearest = Math.min(nearest, h.distanceTo(mc.player));
                float prox = (float) (1.0 - Math.min(nearest, 64.0) / 64.0);
                spike = Math.max(spike, 0.3f + prox * 1.2f);
            } else if (heroPresent) {
                spike = 3.0f;
                mc.getSoundManager().play(PositionedSoundInstance.master(
                        SoundEvents.ENTITY_ENDERMAN_SCREAM, 0.5f, 1.0f));
            }
            heroPresent = present;
        }

        if (RNG.nextInt(1200) == 0) {
            mc.getSoundManager().play(PositionedSoundInstance.master(
                    SoundEvents.AMBIENT_CAVE.value(), 0.6f + RNG.nextFloat() * 0.4f, 0.8f));
        }

        if (--cooldown <= 0) {
            spike = 2.2f;
            mc.getSoundManager().play(PositionedSoundInstance.master(
                    SoundEvents.ENTITY_ENDERMAN_STARE, 0.5f, 0.6f));
            cooldown = 400 + RNG.nextInt(1200); // 20 a 80 segundos
        }
    }

    public static void render(float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!VhsHorrorClient.enabled || mc.world == null) return;

        try {
            if (chain == null) {
                chain = new PostEffectProcessor(mc.getTextureManager(), mc.getResourceManager(),
                        mc.getFramebuffer(), SHADER);
                lastW = lastH = -1;
            }
        } catch (IOException | RuntimeException e) {
            VhsHorrorClient.enabled = false;
            e.printStackTrace();
            return;
        }

        int w = mc.getWindow().getFramebufferWidth();
        int h = mc.getWindow().getFramebufferHeight();
        if (w != lastW || h != lastH) {
            chain.setupDimensions(w, h);
            lastW = w;
            lastH = h;
        }

        float intensity = BASE + spike;
        for (PostEffectPass pass : ((PostEffectProcessorAccessor) chain).vhs$getPasses()) {
            GlUniform u = pass.getProgram().getUniformByName("Intensity");
            if (u != null) u.set(intensity);
        }

        RenderSystem.disableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.resetTextureMatrix();
        chain.render(tickDelta);
        mc.getFramebuffer().beginWrite(false);
        RenderSystem.enableDepthTest();
    }
}
