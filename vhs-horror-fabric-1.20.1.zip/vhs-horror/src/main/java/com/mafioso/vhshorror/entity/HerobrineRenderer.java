package com.mafioso.vhshorror.entity;

import com.mafioso.vhshorror.VhsHorrorClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.feature.EyesFeatureRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.Identifier;

public class HerobrineRenderer extends MobEntityRenderer<HerobrineEntity, PlayerEntityModel<HerobrineEntity>> {
    private static final Identifier TEXTURE = new Identifier(VhsHorrorClient.MOD_ID, "textures/entity/herobrine.png");
    private static final Identifier EYES = new Identifier(VhsHorrorClient.MOD_ID, "textures/entity/herobrine_eyes.png");

    public HerobrineRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false), 0.5f);
        this.addFeature(new EyesFeatureRenderer<HerobrineEntity, PlayerEntityModel<HerobrineEntity>>(this) {
            @Override
            public RenderLayer getEyesTexture() {
                return RenderLayer.getEyes(EYES);
            }
        });
    }

    @Override
    public Identifier getTexture(HerobrineEntity entity) {
        return TEXTURE;
    }
}
