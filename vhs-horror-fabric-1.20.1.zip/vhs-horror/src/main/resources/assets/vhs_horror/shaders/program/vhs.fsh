#version 150

uniform sampler2D DiffuseSampler;
uniform vec2 OutSize;
uniform float Time;      // 0..1, repete a cada segundo
uniform float Intensity; // 0..3

in vec2 texCoord;
out vec4 fragColor;

float rand(vec2 co) {
    return fract(sin(dot(co, vec2(12.9898, 78.233))) * 43758.5453);
}

void main() {
    vec2 uv = texCoord;
    float k = clamp(Intensity, 0.0, 3.0);
    float seed = floor(Time * 24.0);

    // tremor da fita
    uv.x += sin(uv.y * 60.0 + Time * 6.2831 * 4.0) * 0.0012 * k;

    // faixa de tracking subindo pela tela
    float bandY = fract(1.0 - Time);
    float band = smoothstep(0.06, 0.0, abs(uv.y - bandY));
    uv.x += band * (rand(vec2(seed, 1.0)) - 0.5) * 0.06 * k;

    // linhas tremendo aleatoriamente
    float line = floor(uv.y * OutSize.y / 3.0);
    float hit = step(0.97, rand(vec2(seed, line)));
    uv.x += (rand(vec2(line, seed)) - 0.5) * 0.01 * k * hit;

    uv = clamp(uv, vec2(0.0), vec2(1.0));

    // aberracao cromatica
    float ca = (0.0025 + band * 0.01) * k;
    float r = texture(DiffuseSampler, uv + vec2(ca, 0.0)).r;
    float g = texture(DiffuseSampler, uv).g;
    float b = texture(DiffuseSampler, uv - vec2(ca, 0.0)).b;
    vec3 col = vec3(r, g, b);

    // cor lavada e levemente esverdeada
    float luma = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(luma), col, 0.65);
    col *= vec3(0.95, 1.0, 0.92);

    // scanlines
    float scan = 0.88 + 0.12 * sin(uv.y * OutSize.y * 3.14159);
    col *= mix(1.0, scan, clamp(k, 0.0, 1.0));

    // ruido de fita
    float n = rand(uv * OutSize + seed) - 0.5;
    col += n * 0.10 * k;
    col += band * 0.08;

    // vinheta
    vec2 q = texCoord - 0.5;
    col *= 1.0 - dot(q, q) * 1.2;

    fragColor = vec4(col, 1.0);
}
